using System.Reflection;

namespace DateTimeForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void btClear_Click(object sender, EventArgs e)
        {
            txtDay.Clear();
            txtMonth.Clear();
            txtYear.Clear();
        }

        private void btCheck_Click(object sender, EventArgs e)
        {
            int day = DateTimeChecker.GetDayInput(txtDay.Text);
            int month = DateTimeChecker.GetMonthInput(txtMonth.Text);
            int year = DateTimeChecker.GetYearInput(txtYear.Text);
            /* Correct format */
            if (day != 0 && month != 0 && year != 0)
            {
                if (DateTimeChecker.IsValidDay(day) && DateTimeChecker.IsValidMonth(month) && DateTimeChecker.IsValidYear(year))
                {
                    if (DateTimeChecker.IsValidDate(day, month, year))
                    {
                        MessageBox.Show($"{day}//{month}//{year} is correct date time!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    else
                    {
                        MessageBox.Show($"{day}//{month}//{year} is NOT correct date time!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                }
                /* Out of range */
                else
                {
                    bool isValidDay = DateTimeChecker.IsValidDay(day);
                    bool isValidMonth = DateTimeChecker.IsValidMonth(month);
                    bool isValidYear = DateTimeChecker.IsValidYear(year);
                    //Day is out of range
                    if (!isValidDay && isValidMonth && isValidYear)
                    {
                        MessageBox.Show("Input data for Day is out of range!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    //Month is out of range
                    else if (isValidDay && !isValidMonth && isValidYear)
                    {
                        MessageBox.Show("Input data for Month is out of range!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    //Year is out of range
                    else if (isValidDay && isValidMonth && !isValidYear)
                    {
                        MessageBox.Show("Input data for Year is out of range!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    //Day, Month are out of range
                    else if (!isValidDay && !isValidMonth && isValidYear)
                    {
                        MessageBox.Show("Input data for Day, Month is out of range!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    //Day, Year are out of range
                    else if (!isValidDay && isValidMonth && !isValidYear)
                    {
                        MessageBox.Show("Input data for Day, Year is out of range!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    //Month, Year are out of range
                    else if (isValidDay && !isValidMonth && !isValidYear)
                    {
                        MessageBox.Show("Input data for Month, Year is out of range!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    //Day, Month, Year are out of range
                    else if (!isValidDay && !isValidMonth && !isValidYear)
                    {
                        MessageBox.Show("Input data for Day, Month, Year is out of range!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            /* Wrong format */
            else
            {
                //Invalid Day format.
                if (day == 0 && month != 0 && year != 0)
                {
                    MessageBox.Show("Input data for Day is incorrect format!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                //Invalid Month format.
                else if (day != 0 && month == 0 && year != 0)
                {
                    MessageBox.Show("Input data for Month is incorrect format!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                //Invalid Year format.
                else if (day != 0 && month != 0 && year == 0)
                {
                    MessageBox.Show("Input data for Year is incorrect format!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                //Invalid Day, Month format.
                else if (day == 0 && month == 0 && year != 0)
                {
                    MessageBox.Show("Input data for Day and Month is incorrect format!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                //Invalid Day, Year format.
                else if (day == 0 && month != 0 && year == 0)
                {
                    MessageBox.Show("Input data for Day and Year is incorrect format!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                //Invalid Month, Year format.
                else if (day != 0 && month == 0 && year == 0)
                {
                    MessageBox.Show("Input data for Year and Month is incorrect format!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                //Invalid Day, Month, Year format
                else if (day == 0 && month == 0 && year == 0)
                {
                    MessageBox.Show("Input data for Day, Month, Year is incorrect format!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}