﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DateTimeForm
{
    public class DateTimeChecker
    {

        public static bool IsValidDate(int day, int month, int year)
        {
            bool isValid = false;
            int daysInMonth = CheckDaysInMonth(month, year);
            if (daysInMonth != 0)
            {
                if (day >= 1 && day <= daysInMonth)
                {
                    isValid = true;
                }
            }
            return isValid;
        }
        public static bool IsLeapYear(int year)
        {
            bool result = false;
            if (year % 400 == 0)
            {
                result = true;
            }
            else if (year % 100 == 0)
            {
                result = false;
            }
            else if (year % 4 == 0)
            {
                result = true;
            }
            return result;
        }
        public static int CheckDaysInMonth(int month, int year)
        {
            var monthWith31 = new int[] { 1, 3, 5, 7, 8, 10, 12 };
            var monthWith30 = new int[] { 4, 6, 9, 11 };
            if (monthWith31.Contains(month))
            {
                return 31;
            }
            else if (monthWith30.Contains(month))
            {
                return 30;
            }
            else if (month == 2)
            {
                if (IsLeapYear(year))
                {
                    return 29;
                }
                return 28;
            }
            return 0;
        }

        public static bool IsValidDay(int day)
        {
            return day >= 0 && day <= 31;

        }

        public static bool IsValidMonth(int month)
        {
            return month >= 1 && month <= 12;
        }

        public static bool IsValidYear(int year)
        {
            return year >= 1000 && year <= 3000;
        }

        public static int GetDayInput(string txtDay)
        {
            try
            {
                int day = Int32.Parse(txtDay);
                return day;
            }
            catch (FormatException)
            {
                return 0;
            }
        }

        public static int GetMonthInput(string txtMonth)
        {
            try
            {
                int month = Int32.Parse(txtMonth);
                return month;
            }
            catch (FormatException)
            {
                return 0;
            }
        }

        public static int GetYearInput(string txtYear)
        {
            try
            {
                int year = Int32.Parse(txtYear);
                return year;
            }
            catch (FormatException)
            {
                return 0;
            }
        }


    }
}
