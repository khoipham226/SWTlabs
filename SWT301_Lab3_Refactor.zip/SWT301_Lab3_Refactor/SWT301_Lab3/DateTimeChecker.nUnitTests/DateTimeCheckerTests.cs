namespace DateTimeChecker.nUnitTests
{
    public class DateTimeCheckerTests
    {
        [SetUp]
        public void Setup()
        {
        }

        [TestCase(31,1, 2020)]
        [TestCase(28, 2, 2021)]
        [TestCase(28, 2, 2019)]
        [TestCase(30, 9, 2019)]
        [TestCase(30, 6, 2021)]
        [TestCase(0, 15, 2019)]
        [TestCase(0, 8, -5)]
        [TestCase(0, 15, -5)]
        [TestCase(29, 2, 2020)]
        [TestCase(0, 2, 10)]
        [TestCase(0, null, 2019)]
        [TestCase(0, 3, null)]
        [TestCase(0, null, -5)]
        [TestCase(0, null, null)]
        [TestCase(0, 15, null)]
        public void CheckDaysInMonth_Test(int expected, int? month, int? year)
        {
            
            int days = DateTimeChecker.CheckDaysInMonth(month, year);
            Assert.That(days, Is.EqualTo(expected));
        }
        [TestCase(true, 29, 2, 2000)]
        [TestCase(false, 29, 2, 2009)]
        [TestCase(false, 31, 2, 2020)]
        [TestCase(true, 28, 2, 2000)]
        [TestCase(true, 1, 4, 2020)]
        [TestCase(false, null, 2, 2000)]
        [TestCase(true, 28, 2, 2009)]
        [TestCase(true, 1, 3, 2020)]
        [TestCase(true, 30, 3, 2020)]
        [TestCase(true, 30, 6, 2020)]
        [TestCase(false, 31, null, 2009)]
        [TestCase(false, 29, 3, null)]
        [TestCase(true, 2, 6, 2002)]
        [TestCase(false, 34, 7, 2019)]
        [TestCase(false, 20, 15, 2020)]
        [TestCase(false, 20, 11, -2)]
        public void IsValidDate_Test(bool expected, int? day, int? month, int? year)
        {
            bool isValid = DateTimeChecker.IsValidDate(day, month, year);
            Assert.That(isValid, Is.EqualTo(expected));
        }
    }
}