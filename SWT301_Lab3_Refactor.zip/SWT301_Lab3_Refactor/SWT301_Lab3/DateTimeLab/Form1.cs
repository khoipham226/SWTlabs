namespace DateTimeLab
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void btClear_Click(object sender, EventArgs e)
        {
            txtDay.Clear();
            txtMonth.Clear();
            txtYear.Clear();
        }

        private void btCheck_Click(object sender, EventArgs e)
        {
            int day = DateTimeChecker.GetDayInput(txtDay.Text);
            int month = DateTimeChecker.GetMonthInput(txtMonth.Text);
            int year = DateTimeChecker.GetYearInput(txtYear.Text);
            /* Correct format */
            if (day != 0 && month != 0 && year != 0)
            {
                bool isValidDay = DateTimeChecker.IsValidDay(day);
                bool isValidMonth = DateTimeChecker.IsValidMonth(month);
                bool isValidYear = DateTimeChecker.IsValidYear(year);
                if (isValidDay && isValidMonth && isValidYear)
                {
                    string result = (DateTimeChecker.IsValidDate(day, month, year)) ? "is correct date time!" : "is NOT correct date time!";
                    MessageBox.Show($"{day}//{month}//{year} {result}", "Message", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                /* Out of range */
                else
                {
                    MessageBox.Show(DateTimeChecker.OutOfRangeErrorMessage(isValidDay, isValidMonth, isValidYear), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
            /* Wrong format */
            else
            {
                MessageBox.Show(DateTimeChecker.FormatErrorMessage(day, month, year), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}