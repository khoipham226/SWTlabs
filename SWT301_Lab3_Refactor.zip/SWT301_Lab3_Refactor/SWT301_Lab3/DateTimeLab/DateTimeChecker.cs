﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DateTimeLab
{
    public class DateTimeChecker
    {

        public static bool IsValidDate(int? day, int? month, int? year)
        {
            bool isValid = false;
            int daysInMonth = CheckDaysInMonth(month, year);
            if (daysInMonth != 0)
            {
                if (day >= 1 && day <= daysInMonth)
                {
                    isValid = true;
                }
            }
            return isValid;
        }
        public static bool IsLeapYear(int? year)
        {
            bool isLeapYear = false;
            if (year != null)
            {
                if (year % 400 == 0)
                {
                    isLeapYear = true;
                }
                else if (year % 100 == 0)
                {
                    isLeapYear = false;
                }
                else if (year % 4 == 0)
                {
                    isLeapYear = true;
                }
            }
            return isLeapYear;
        }
        public static int CheckDaysInMonth(int? month, int? year)
        {
            var monthWith31 = new int?[] { 1, 3, 5, 7, 8, 10, 12 };
            var monthWith30 = new int?[] { 4, 6, 9, 11 };
            int days = 0;
            if (month != null && year != null && IsValidMonth(month) && IsValidYear(year))
            {
                if (monthWith31.Contains(month))
                {
                    days = 31;
                }
                else if (monthWith30.Contains(month))
                {
                    days = 30;
                }
                else if (month == 2)
                {
                    if (IsLeapYear(year))
                    {
                        days = 29;
                    }
                    else
                    {
                        days = 28;
                    }
                }
            }
            return days;
        }

        public static bool IsValidDay(int? day)
        {
            return day >= 0 && day <= 31;

        }

        public static bool IsValidMonth(int? month)
        {
            return month >= 1 && month <= 12;
        }

        public static bool IsValidYear(int? year)
        {
            return year >= 1000 && year <= 3000;
        }

        public static int GetDayInput(string txtDay)
        {
            try
            {
                int day = Int32.Parse(txtDay);
                return day;
            }
            catch (FormatException)
            {
                return 0;
            }
        }

        public static int GetMonthInput(string txtMonth)
        {
            try
            {
                int month = Int32.Parse(txtMonth);
                return month;
            }
            catch (FormatException)
            {
                return 0;
            }
        }

        public static int GetYearInput(string txtYear)
        {
            try
            {
                int year = Int32.Parse(txtYear);
                return year;
            }
            catch (FormatException)
            {
                return 0;
            }
        }

        public static string OutOfRangeErrorMessage(bool isValidDay, bool isValidMonth, bool isValidYear)
        {
            string message = string.Empty;
            //Day is out of range
            if (!isValidDay && isValidMonth && isValidYear)
            {
                message = "Input data for Day is out of range!";
            }
            //Month is out of range
            else if (isValidDay && !isValidMonth && isValidYear)
            {
                message = "Input data for Month is out of range!";
            }
            //Year is out of range
            else if (isValidDay && isValidMonth && !isValidYear)
            {
                message = "Input data for Year is out of range!";
            }
            //Day, Month are out of range
            else if (!isValidDay && !isValidMonth && isValidYear)
            {
                message = "Input data for Day, Month is out of range!";
            }
            //Day, Year are out of range
            else if (!isValidDay && isValidMonth && !isValidYear)
            {
                message = "Input data for Day, Year is out of range!";
            }
            //Month, Year are out of range
            else if (isValidDay && !isValidMonth && !isValidYear)
            {
                message = "Input data for Month, Year is out of range!";
            }
            //Day, Month, Year are out of range
            else if (!isValidDay && !isValidMonth && !isValidYear)
            {
                message = "Input data for Day, Month, Year is out of range!";
            }
            return message;
        }

        public static string FormatErrorMessage(int day, int month, int year)
        {
            string message = string.Empty;
            //Invalid Day format.
            if (day == 0 && month != 0 && year != 0)
            {
                message = "Input data for Day is incorrect format!";
            }
            //Invalid Month format.
            else if (day != 0 && month == 0 && year != 0)
            {
                message = "Input data for Month is incorrect format!";
            }
            //Invalid Year format.
            else if (day != 0 && month != 0 && year == 0)
            {
                message = "Input data for Year is incorrect format!";
            }
            //Invalid Day, Month format.
            else if (day == 0 && month == 0 && year != 0)
            {
                message = "Input data for Day, Month is incorrect format!";
            }
            //Invalid Day, Year format.
            else if (day == 0 && month != 0 && year == 0)
            {
                message = "Input data for Day, Year is incorrect format!";
            }
            //Invalid Month, Year format.
            else if (day != 0 && month == 0 && year == 0)
            {
                message = "Input data for Month, Year is incorrect format!";
            }
            //Invalid Day, Month, Year format
            else if (day == 0 && month == 0 && year == 0)
            {
                message = "Input data for Day, Month, Year is incorrect format!";
            }
            return message;
        }


    }
}
