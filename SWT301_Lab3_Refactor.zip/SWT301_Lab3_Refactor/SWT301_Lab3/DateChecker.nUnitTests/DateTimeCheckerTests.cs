using DateTimeLab;
namespace DateChecker.nUnitTests
{
    public class DateTimeCheckerTests
    {
        private DateTimeChecker _dateTimeChecker { get; set; } = null!;
        [SetUp]
        public void Setup()
        {
            _dateTimeChecker = new DateTimeChecker();
        }

        [Test]
        public void CheckDaysInMonth_Test()
        {
            Assert.Pass();
        }
    }
}