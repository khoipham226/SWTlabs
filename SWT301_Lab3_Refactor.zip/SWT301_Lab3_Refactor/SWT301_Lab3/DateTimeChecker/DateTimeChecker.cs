﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DateTimeChecker
{
    public class DateTimeChecker
    {

        public static bool IsValidDate(int? day, int? month, int? year)
        {
            bool isValid = false;
            int daysInMonth = CheckDaysInMonth(month, year);
            if (daysInMonth != 0)
            {
                if (day >= 1 && day <= daysInMonth)
                {
                    isValid = true;
                }
            }
            return isValid;
        }
        public static bool IsLeapYear(int? year)
        {
            bool isLeapYear = false;
            if (year != null)
            {
                if (year % 400 == 0)
                {
                    isLeapYear = true;
                }
                else if (year % 100 == 0)
                {
                    isLeapYear = false;
                }
                else if (year % 4 == 0)
                {
                    isLeapYear = true;
                }
            }
            return isLeapYear;
        }
        public static int CheckDaysInMonth(int? month, int? year)
        {
            var monthWith31 = new int?[] { 1, 3, 5, 7, 8, 10, 12 };
            var monthWith30 = new int?[] { 4, 6, 9, 11 };
            int days = 0;
                if (month != null && year != null && IsValidMonth(month) && IsValidYear(year))
                {
                    if (monthWith31.Contains(month))
                    {
                        days = 31;
                    }
                    else if (monthWith30.Contains(month))
                    {
                        days = 30;
                    }
                    else if (month == 2)
                    {
                        if (IsLeapYear(year))
                        {
                            days = 29;
                        }
                        else
                        {
                            days = 28;
                        }
                    }
                }
            return days;
        }
        public static bool IsValidDay(int? day)
        {
            return day >= 0 && day <= 31;

        }

        public static bool IsValidMonth(int? month)
        {
            return month >= 1 && month <= 12;
        }

        public static bool IsValidYear(int? year)
        {
            return year >= 1000 && year <= 3000;
        }
    }
}